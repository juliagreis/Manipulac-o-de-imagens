// INF110 - Trabalho pratico 3
//
// programa para ler, modificar e gravar uma imagem no formato PNM
//
// Autores: Andre Gustavo dos Santos			(criado em 16/06/14)
//          Andre Gustavo dos Santos			(modificado em 22/05/18)
//					Andre Gustavo dos Santos			(modificado em 13/09/21)
//					Andre Gustavo dos Santos			(modificado em 15/07/24)


#include<iostream>
#include<fstream>
#include<cstring>
#include<cmath>
#include <cstdlib>
#include <cctype>

const int MAXALTURA  = 500;				//tamanho maximo aceito 
const int MAXLARGURA = 500;

using namespace std;


int main(){
	unsigned char imagemcolorida[MAXALTURA][MAXLARGURA][3];
	unsigned char imagemcinza[MAXALTURA][MAXLARGURA];	//a imagem propriamente dita
	int largura, altura;						//dimensoes da imagem
	char tipo[4];										//tipo da imagem
	ifstream arqentrada;						//arquivo que contem a imagem original
	ofstream arqsaida;							//arquivo que contera a imagem modificada
	char comentario[200], c;				//auxiliares
	int i, j, k, valor;								//auxiliares
	string nomearquivo;                    //nome do arquivo pnm

//*** LEITURA DA IMAGEM ***//
//inicialmente nao sera necessario entender nem mudar nada nesta parte
	cout<<"Digite o nome do arquivo PNM que deseja abrir: ";
	getline(cin,nomearquivo);
	//*** Abertura do arquivo ***//
	arqentrada.open(nomearquivo,ios::in); //Abre arquivo para leitura
	if (!arqentrada) {
		std::cout << "Nao consegui abrir arquivo "<<nomearquivo<< endl;
		return 0;
	}
//***************************//


//*** Leitura do cabecalho ***//
	arqentrada >> tipo;	//Le o tipo de arquivo
	arqentrada.get();		//Le e descarta o \n do final da 1a. linha

	bool coloridap3=false;   //seleciona o tipo de matriz
	bool cinzap2=false;      //seleciona o tipo de matriz

	if (strcmp(tipo,"P2")==0) {
		cout << "Imagem em tons de cinza\n";
		cinzap2=true;       //seleciona matriz de duas dimensoes
	}
	else if (strcmp(tipo,"P3")==0) {
		cout << "Imagem colorida\n";
		coloridap3=true;   //seleciona matriz de tres dimensoes
	} 
	else if (strcmp(tipo,"P1")==0) {
		cout << "Imagem preto e branco\n";
		cout << "Desculpe, nao trabalho com esse tipo de imagem.\n";
		arqentrada.close();
		return 0;
	}
	else if (strcmp(tipo,"P4")==0 || strcmp(tipo,"P5")==0 || strcmp(tipo,"P6")==0) {
		cout << "Imagem no formato RAW\n";
		cout << "Desculpe, nao trabalho com esse tipo de imagem.\n";
		arqentrada.close();
		return 0;
	}

	while((c = arqentrada.get()) == '#')	//Enquanto for comentario
		arqentrada.getline(comentario,200);	//Le e descarta a linha "inteira"

	arqentrada.putback(c);	//Devolve o caractere lido para a entrada, pois como
													//nao era comentario, era o primeiro digito da largura

	arqentrada >> largura >> altura;	//Le as dimensoes da imagem, numero de pixels da horizontal e da vertical
	cout << "Tamanho: " << largura << " x " << altura << endl;
	if (largura > MAXLARGURA) {
		std::cout << "Desculpe, ainda nao trabalho com imagens com mais de " << MAXLARGURA << " pixels de largura.\n";
		arqentrada.close();
		return 0;
	}
	if (altura > MAXALTURA) {
		std::cout << "Desculpe, ainda nao trabalho com imagens com mais de " << MAXALTURA << " pixels de altura.\n";
		arqentrada.close();
		return 0;
	}

	arqentrada >> valor;	//Valor maximo do pixel (temos que ler, mas nao sera usado, assumimos 255)
	//****************************//


	//*** Leitura dos pixels da imagem ***//

	if(cinzap2){                                        //leitura dos pixels de imagens cinzas
		for(i=0;i<altura;i++)
			for(j=0;j<largura;j++){
				arqentrada >> valor;
				imagemcinza[i][j] = (unsigned char)valor;
			}
	}


	if(coloridap3){                                    //leitura de pixels de imagens coloridas
		for(i=0;i<altura;i++)
			for(j=0;j<largura;j++)
				for(k=0;k<3;k++){
					arqentrada >> valor;
					imagemcolorida[i][j][k] = (unsigned char)valor;
				}
	}

	//************************************//

	arqentrada.close();  //Fecha arquivo apos a leitura

	//*** FIM DA LEITURA DA IMAGEM ***//


	//*** TRATAMENTO DA IMAGEM ***//
	//inicialmente sera nesta parte do codigo que voce vai trabalhar

	//selecionando qual filtro deseja usar
	cout<<"\nDigite o número correspondente ao filtro que deseja utilizar\n";
	cout<<"============================================================"<<endl;


	int contfiltro=0;          //contador que impede que seja salva uma imagem sem aplicacao de filtros
	bool continuar=true;      //verificador de aplicacao de mais de um filtro

	while(continuar==true){   //permitindo aplicacao de mais de um filtro

		int qualfiltro;
		if(contfiltro>0){     //caso nao seja o primeiro filtro aplicado
			cout<<"Selecione outro filtro:\n";
		}

		cout<<"(1) Escurecimento\n(2) Clareamento\n(3) Negativo\n(4) Espelhar\n(5) Filtro de Prewitt\n";
		cout<<"(6) Filtro de Laplace\n(7) Posterização\n";
		if(coloridap3) //filtro disponivel apenas para imagens coloridas
			cout<<"(8) Transformar em imagem tons de cinza\n";
		cout<<"(0)Encerrar programa\n";
		cout<<"============================================================\n"<<endl;
	
		cin>>qualfiltro;

		if(qualfiltro==0){    //encerrando programa
			continuar=false;  //booleano de parada do programa
			break;
		}
		else{
			contfiltro++;
		}
		

	

		//----FILTRO DE ESCURECIMENTO----//
		if (qualfiltro==1){

			int fator;
			cout << "Qual o fator de escurecimento (1-100)? ";
			cin >> fator;

			//escurecendo imagem colorida

			if(coloridap3){               		//tratando a matriz colorida
				for(i=0;i<altura;i++){
					for(j=0;j<largura;j++) {
						for(k=0;k<3;k++){

							valor = (int)imagemcolorida[i][j][k];										
							valor -= fator;	

							if (valor < 0)		//tratando para o intervalo [0,255]
								valor = 0;	
							imagemcolorida[i][j][k] = (unsigned char)valor;   

						}
					}
				}
			}

			//escurecendo imagem cinza;
			if(cinzap2){		//tratando matriz cinza
				for(i=0;i<altura;i++)
					for(j=0;j<largura;j++) {
						valor = (int)imagemcinza[i][j];							//pega o valor do pixel
						valor -= fator;											//escurece o pixel
						if (valor < 0)											//se der negativo
							valor = 0;											//  deixa preto
						imagemcinza[i][j] = (unsigned char)valor;				//modifica o pixel
					}
			}	
		}
    	//*************************//

	
		//----FILTRO DE CLAREAMENTO----//
		if(qualfiltro==2){

			int fator;
			cout << "Qual o fator de clareamento (1-100)? ";
			cin >> fator;

			if(cinzap2){    //Clarea a imagem tons de cinza

				for(i=0;i<altura;i++)
					for(j=0;j<largura;j++) {

						valor = (int)imagemcinza[i][j];							//pega o valor do pixel
						valor += fator;											//escurece o pixel
						if (valor > 255)										//se der negativo
							valor = 255;										//  deixa preto
						imagemcinza[i][j] = (unsigned char)valor;				//modifica o pixel

						}
			}

			if(coloridap3){		//Clarea a imagem colorida
				for(i=0;i<altura;i++)
					for(j=0;j<largura;j++) {
						for(k=0;k<3;k++){
							valor = (int)imagemcolorida[i][j][k];				//pega o valor do pixel
							valor += fator;										//escurece o pixel
							if (valor > 255)									//se der negativo
								valor = 255;									//  deixa preto
							imagemcolorida[i][j][k] = (unsigned char)valor;		//modifica o pixel
						}
					}
			}
		}

		//*************************//

		//-----FILTRO NEGATIVO ----//
		if(qualfiltro==3){

			if(cinzap2){ 	//Imagem com tons de cinza

				for(i=0;i<altura;i++)
					for(j=0;j<largura;j++) {
						valor = (int)imagemcinza[i][j];			   				//guardando valor do pixel
						valor = abs(valor-255);									//calculando complemento de 255 												
						imagemcinza[i][j] = (unsigned char)valor;				//modificando pixel
					}
			}
		
			if(coloridap3){		//Imagem colorida

				for(i=0;i<altura;i++)
					for(j=0;j<largura;j++) {
						for(k=0;k<3;k++){
							valor = (int)imagemcolorida[i][j][k];				//guardando valor do pixel
							valor = abs(valor-255);								//calculando complemento de 255 									
							imagemcolorida[i][j][k] = (unsigned char)valor;		//modificando pixel
						}
					}
			}
		}
		//*************************//


		//----Imagem espelhada----//
		if(qualfiltro==4){

			//menu de espelho
			cout<<"Deseja espelhar de qual maneira?\n(1) Verticalmente\n(2) Horizontalmente\n";
			int op_espelho;
			cin>>op_espelho;

			if(cinzap2){  					//imagem tons de cinza

				if(op_espelho==1){ 			//espelhando verticalmente 

					for(i=0; i<altura; i++) { 	      						//passando pelas linhas
						for(j=0;j<largura/2;j++){      						//passando pelas colunas e parando na metade p/ nao reinverter
      
    						int aux = imagemcinza[i][j];					//variavel auxiliar p/ inverter pixels
    						imagemcinza[i][j] = imagemcinza[i][largura-j-1];
    						imagemcinza[i][largura-j-1] = aux;
    					}
  					}
				}
		
				if(op_espelho==2){ 			//espelhando verticalmente imagem cinza

					for(i=0; i<altura/2; i++) {      							//passando pelas linhas e parando na metade p/nao reinverter
						for(j=0;j<largura;j++){       							//passando pelas colunas
    						int aux = imagemcinza[i][j];						//variavel auxiliar p/ inverter pixels
    						imagemcinza[i][j] = imagemcinza[altura-i-1][j];
    						imagemcinza[altura-i-1][j] = aux;
    					}
  					}
				}
			}

			if(coloridap3){				//imagem colorida

				if(op_espelho==1){		//espelhando verticalmente

					for(i=0;i<altura;i++){            							//passando pelas linhas
						for(j=0;j<largura/2;j++){     							//passando por cada coluna e parando na metade p/ nao reinverter
							for(k=0;k<3;k++){         							//passando pelos fatores de cor
								int aux=imagemcolorida[i][j][k];				//variavel auxiliar p/ inverter pixels
								imagemcolorida[i][j][k] = imagemcolorida[i][largura-j-1][k];
    							imagemcolorida[i][largura-j-1][k] = aux;		
							}
						}
					}
				}

				if(op_espelho==2){		//espelhando horizontalmente 

					for(i=0;i<altura/2;i++){         							//parando no meio da matriz para nao reinverter
						for(j=0;j<largura;j++){      							//passando por cada coluna
							for(k=0;k<3;k++){        							//passando pelos fatores de cor
								int aux=imagemcolorida[i][j][k];				//variavel auxiliar p/ inverter pixels
								imagemcolorida[i][j][k] = imagemcolorida[altura-i-1][j][k];
    							imagemcolorida[altura-i-1][j][k] = aux;
							}
						}
					}
				}
			}
		}
		//*************************//

		//----FILTRO DE PREWITT----//
		if(qualfiltro==5){

			if(cinzap2){ 		//aplicando o filtro em imagens tons de cinza

				int copiamatriz[altura][largura];
				//gravando uma copia da matriz original
				for(i=0;i<altura;i++){
					for(j=0;j<largura;j++){
						copiamatriz[i][j]=imagemcinza[i][j];
					}
				}

				//declarando matrizes do filtro de prewitt
				int m1[3][3]={{1,0,-1},
					     	  {1,0,-1},
					      	  {1,0,-1}};

            	int m2[3][3]={{1,1,1},
						  	  {0,0,0},
						  	  {-1,-1,-1}};
            
				//percorrendo cada elemento da matriz e ignorando as bordas
				for(i=1;i<altura-1;i++){
                	for(j=1;j<largura-1;j++){
	
						int gx=0;	 	//acumulador de m1
						int gy=0; 		//acumulador de m2
			
						//percorrendo os 9 elementos para que a matriz gx e gy seja aplicada
						for(int m=0;m<3;m++){ 
							for(int n=0;n<3;n++){

								gx+=copiamatriz[i+m-1][j+n-1]*m1[m][n];
								gy+=copiamatriz[i+m-1][j+n-1]*m2[m][n];	
							}
						}
						int filtro=(sqrt(gx*gx+gy*gy));
					
						
						if(filtro>255) 					//impedindo valores invalidos para tons de cinza
							imagemcinza[i][j]=255;
						else
							imagemcinza[i][j]=filtro; 	//se esta no intervalo [0,255]
					}
				}
			}
			

			if(coloridap3){			//imagens coloridas

				int copiacolorida[altura][largura][3];
				//gravando uma copia da matriz original
				for(i=0;i<altura;i++){
					for(j=0;j<largura;j++){
						for(int k=0;k<3;k++)
							copiacolorida[i][j][k]=imagemcolorida[i][j][k];
					}
				}

				//declarando matrizes do filtro de prewitt
				int m1[3][3]={{1,0,-1},
					          {1,0,-1},
					          {1,0,-1}};

            	int m2[3][3]={{1,1,1},
						      {0,0,0},
						      {-1,-1,-1}};

				//percorrendo cadaelemento da matriz e ignorando as bordas
				for(i=1;i<altura-1;i++){
                	for(j=1;j<largura-1;j++){
						for(int k=0;k<3;k++){	

							int gx=0;			//acumulador de m1
							int gy=0; 			//acumulador de m2

							//percorrendo os 9 elementos para que a matriz gx e gy seja aplicada
							for(int m=0;m<3;m++){ 
								for(int n=0;n<3;n++){

									gx+=copiacolorida[i+m-1][j+n-1][k]*m1[m][n]; 
									gy+=copiacolorida[i+m-1][j+n-1][k]*m2[m][n];	
								}
							}
							int filtro=(sqrt(gx*gx+gy*gy));
					
							if(filtro>255) 						//impedindo valores invalidos para tons de cinza
								imagemcolorida[i][j][k]=255;
							else
								imagemcolorida[i][j][k]=filtro; //se esta no intervalo [0,255]
						}	
					}
				}
			}
		}
		//*************************//


		//----TRANSFORMANDO COLORIDA EM TONS DE CINZA----//
		if(qualfiltro==8&&coloridap3){  //verificando se é colorida, caso o usuario digite 6 sem querer
			int media=0;
			for(int i=0;i<altura;i++){
				for(int j=0;j<largura;j++){
					media=0;
					for(int k=0;k<3;k++){
						media+=imagemcolorida[i][j][k];  //acumulador para calcular media das cores
					}
					for(int k=0;k<3;k++){
						imagemcolorida[i][j][k]=media/3;  
					}
				}
			}
			break;       //impede que uma imagem convertida p/ tons de cinza seja manipulada por outras operacoes do programa
		}
		
		//*************************//


		//FILTRO DE LAPLACE
		if(qualfiltro==6){

			if(cinzap2){	//imagens tons de cinza

				int copiamatriz[altura][largura];
				//gravando uma copia da matriz original
				for(i=0;i<altura;i++){
					for(j=0;j<largura;j++){
						copiamatriz[i][j]=imagemcinza[i][j];
					}
				}

				//declarando matriz do filtro de laplace
				int filtro[3][3]={{0,-1,0},
					      		  {-1,4,-1},
					      		  {0,-1,0}};
            
				//percorrendo cada elemento da matriz e ignorando as bordas
				for(i=1;i<altura-1;i++){
                	for(j=1;j<largura-1;j++){
						int acumulador=0;
						//percorrendo os 9 elementos para que a matriz seja aplicada
						for(int m=0;m<3;m++){ 
							for(int n=0;n<3;n++){
								acumulador+=copiamatriz[i+m-1][j+n-1]*filtro[m][n];
							}
						}
						if(acumulador>255)				 //impedindo valores invalidos para tons de cinza
							imagemcinza[i][j]=255;
						else if (acumulador<0)
							imagemcinza[i][j]=0;
						else
							imagemcinza[i][j]=acumulador; //se esta no intervalo [0,255]
					}
				}
			}

			if(coloridap3){		//aplicando filtro de laplace em imagens coloridas

				int copiacolorida[altura][largura][3];
				//gravando uma copia da matriz original
				for(i=0;i<altura;i++){
					for(j=0;j<largura;j++){
						for(int k=0;k<3;k++)
						copiacolorida[i][j][k]=imagemcolorida[i][j][k];
					}
				}

				//declarando a matriz do filtro de laplace
				int filtro[3][3]={{0,-1,0},
					      		  {-1,4,-1},
					     		  {0,-1,0}};

				//percorrendo cada elemento da matriz e ignorando as bordas
				for(i=0;i<altura;i++){
                	for(j=0;j<largura;j++){
						for(int k=0;k<3;k++){

							if(i==0||i==altura-1||j==0||j==largura-1) //zerando as bordas p/ nao ficarem coloridas
								imagemcolorida[i][j][k]=0;

							else{                 //caso nao se trate de uma borda... realizar operacoes
							int acumulador=0;

							//percorrendo os 9 elementos para que a matriz gx e gy seja aplicada
							for(int m=0;m<3;m++){ 
								for(int n=0;n<3;n++){
									acumulador+=copiacolorida[i+m-1][j+n-1][k]*filtro[m][n];
								}
							}
					
							if(acumulador>255) 						//impedindo valores invalidos para tons de cinza
								imagemcolorida[i][j][k]=255;
							else if(acumulador<0)
								imagemcolorida[i][j][k]=0;
							else
								imagemcolorida[i][j][k]=acumulador; //se esta no intervalo [0,255]

							}
						}		
					}
				}
			}
		
		}
		//*************************//

//---filtro de posterizacao---//
	if(qualfiltro==7){
		if(coloridap3){

    		int fator = 256 / 4; // Tamanho do intervalo para cada nível
    		// Percorrendo cada pixel da imagem
    		for (int i = 0; i < altura; i++) {
        		for (int j = 0; j < largura; j++) {
            		for (int k = 0; k < 3; k++) { 
                	// Reduz o número de níveis de cor
                	imagemcolorida[i][j][k] = (imagemcolorida[i][j][k] / fator) * fator;
					}
				}
			}
		}
		if(cinzap2){
			int fator = 256 / 4; // Tamanho do intervalo para cada nível
    		// Percorrendo cada pixel da imagem
    		for (int i = 0; i < altura; i++) {
        		for (int j = 0; j < largura; j++) {
					imagemcinza[i][j]=(imagemcinza[i][j]/fator)*fator+fator/2;
				}
			}

		}
	}

}//chave de fim do while
	

//*** FIM DO TRATAMENTO DA IMAGEM ***//


//*** GRAVACAO DA IMAGEM ***//

//caso nao tenha sido aplicado nenhum filtro
if(contfiltro==0){ 
	std::cout<<"Nenhum filtro foi aplicado.\n";
	return 0;  //encerrando programa sem gravar nova imagem
}

//inicialmente nao sera necessario entender nem mudar nada nesta parte
	
	//*** Grava a nova imagem ***//
	string arquivonovo;

	cout<<"Qual será o nome da sua nova imagem?\nLembre-se que este deve ser terminado em ' .pnm ' ";
	cin>>arquivonovo;                    //nome do novo arquivo


	arqsaida.open(arquivonovo,ios::out);	//Abre arquivo para escrita
	if (!arqsaida) {
		std::cout << "Nao consegui criar seu novo arquivo.\n";
		return 0;
	}

	if(cinzap2){

	arqsaida << tipo << endl;							//tipo
	arqsaida << "# TP3-INF110, by AGS\n";	//comentario
	arqsaida << largura << " " << altura;	//dimensoes
	arqsaida << " " << 255 << endl;				//maior valor
	for(i=0;i<altura;i++)
		for(j=0;j<largura;j++)
			arqsaida << (int)imagemcinza[i][j] << endl;	//pixels
	}

	if(coloridap3){
		arqsaida << tipo << endl;							//tipo
		arqsaida << "# TP3-INF110, by AGS\n";	//comentario
		arqsaida << largura << " " << altura;	//dimensoes
		arqsaida << " " << 255 << endl;				//maior valor
		for(i=0;i<altura;i++){
			for(j=0;j<largura;j++){
				for(k=0;k<3;k++)
				arqsaida << (int)imagemcolorida[i][j][k] << endl;	//pixels
			}
		}
	}
	

	arqsaida.close();		//fecha o arquivo
	//***************************//

//*** FIM DA GRAVACAO DA IMAGEM ***//
	cout<<"Imagem "<<arquivonovo<<" gravada com sucesso!"<<endl;	
	return 0;

}
